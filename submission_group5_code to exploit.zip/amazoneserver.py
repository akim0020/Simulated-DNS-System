import errno
import socket
import sys


def listen():
    try:
        while True:
            # Wait for query
            binary_query, client_address = udp_server_local.receive_message()
            record = deserialize(binary_query)

            # Parse query to extract the hostname (domain)
            hostname = record['hostname']
            # print(f"Received query for hostname: {hostname}")

            # Check RR table for record
            check_record = rr_table_local.get_record_by_name(hostname)
            # If not found, add "Record not found" in the DNS response
            # Else, return record in DNS response
            if check_record:
                # print(f"Query/Response: {record}")
                # print(f"Found in RR Table: {check_record}")
                # print("RR Table:")
                rr_table_local.display_table()
                # Send response with the record data
                response = serialize(record['transaction_id'], hostname, record['type'], check_record['result'], is_response=True)
                udp_server_local.send_message(response, client_address)
            else:
                # print(f"Record for {hostname} not found in RR Table, sending 'Record not found' response...")
                # Respond with "Record not found"
                response = serialize(record['transaction_id'], hostname, record['type'], "Record not found", is_response=True)
                udp_server_local.send_message(response, client_address)


            # The format of the DNS query and response is in the project description

            # Display RR table
            # rr_table_local.display_table()

    except KeyboardInterrupt:
        print("Keyboard interrupt received, exiting...")
    finally:
        #Close UDP socket
        udp_server_local.close()


def main():
    # Add initial records
    # These can be found in the test cases diagram
    global rr_table_local
    rr_table_local = RRTable()  # Initialize RR Table

    global udp_server_local 
    udp_server_local = UDPConnection(timeout=1)  # Initialize UDP client

    rr_table_local.add_record("shop.amazone.com","A","3.33.147.88",static=1)
    rr_table_local.add_record("cloud.amazone.com","A","15.197.140.28",static=1)

    amazone_dns_address = ("127.0.0.1", 22000)
    # Bind address to UDP socket
    udp_server_local.bind(amazone_dns_address)

    listen()


def serialize(transaction_id, hostname, query_code, result, is_response=False):
    # Consider creating a serialize function
    # This can help prepare data to send through the socket
    # Convert transaction ID to 4 bytes
    trans_ID_query = transaction_id.to_bytes(4, byteorder='big')
    
    # Convert query type to 1 bytes (DNS query types are 16 bits)
    type_query = query_code.to_bytes(1, byteorder='big')
    
    # Encode hostname
    labels = hostname.split('.') # Split the domain name into labels (splitting by '.')
    domain_bytes = [] # Create a list to hold the encoded domain name bytes

    # For each label in the domain
    for label in labels:
        # Add the length of the label as the first byte
        domain_bytes.append(len(label))
        
        # Add the ASCII values of the characters in the label
        domain_bytes.extend(ord(char) for char in label)

    # Append a null byte to signify the end of the domain name
    domain_bytes.append(0)
    # Convert domain name labels into bytes
    hostname_query = bytes(domain_bytes)

    # Set the flag for query or response
    if not is_response:
        flag = 0b0000 
        flag_query = flag.to_bytes(1, byteorder='big')
        # Combine all parts of the query into a single byte string
        query = trans_ID_query + flag_query + hostname_query + type_query
    else:
        flag = 0x0001   
        flag_query = flag.to_bytes(1, byteorder='big')
        # ttl_query = ttl.to_bytes(4, byteorder='big') #4 bytes
        result_query = socket.inet_aton(result) #4 bytes

        # Combine all parts of the query into a single byte string
        query = trans_ID_query + flag_query + hostname_query + type_query + result_query

    return query


def deserialize(response):
    # Consider creating a deserialize function
    # This can help prepare data that is received from the socket
    # Initialize a pointer to track where we are in the response
    pointer = 0

    # Step 1: Extract the Transaction ID (4 bytes)
    trans_ID = int.from_bytes(response[pointer:pointer + 4], byteorder='big')
    pointer += 4

    # Step 2: Extract the flag (1 byte)
    flag = response[pointer]
    pointer += 1

    # Step 3: Decode the hostname
    labels = []
    while response[pointer] != 0:
        label_len = response[pointer]
        pointer += 1
        label = response[pointer:pointer + label_len].decode('ascii')
        labels.append(label)
        pointer += label_len
    pointer += 1  # Skip the null byte that ends the hostname

    hostname = '.'.join(labels)

    # Step 4: Extract the query type (1 bytes)
    query_type = response[pointer]
    pointer += 1

    # Step 5: Handle Response
    if flag == 0x01:  # This is a response
        # Extract TTL (4 bytes)
        # ttl = int.from_bytes(response[pointer:pointer + 4], byteorder='big')
        # pointer += 4

        # Extract Result (IPv4 address for A record - 4 bytes)
        result_ip = socket.inet_ntoa(response[pointer:pointer + 4])
        pointer += 4

        # Return the deserialized DNS response
        return {
            'transaction_id': trans_ID,
            'flag': flag,
            'hostname': hostname,
            'type': query_type,
            # 'ttl': ttl,
            'result': result_ip
        }
    else:
        # Return the deserialized DNS query (without TTL and result)
        return {
            'transaction_id': trans_ID,
            'flag': flag,
            'hostname': hostname,
            'type': query_type
        }


class RRTable:
    def __init__(self):
            # self.records = ?
            self.records = []  # A list to hold all the records
            self.record_number = 0

    def add_record(self, name, type, result, static):
            
            self.record_number += 1  # Increment record number for the next record
            # Add a new record to the RR table
            record = {
                "record_no": self.record_number,
                "name": name,
                "type": type,
                "result": result,
                "ttl": 60 if static == 0 else None,  # TTL is 60 if dynamic, None if static
                "static": static #static= 0
            }
            self.records.append(record)         
            #pass

    def get_record_by_name(self, name):
        
            # Find and return the record by its name
            for record in self.records:
                if record['name'] == name:
                    return record
            return None  # Return None if no matching record is found
    
    def get_record(self, record_number):
        
            # Find and return the record with the specified record number
            for record in self.records:
                if record['record_no'] == record_number:
                    return record
            return None  # Return None if no matching record is found
            #pass

    def display_table(self):
        
            # Display the table in the following format (include the column names):
            # record_number,name,type,result,ttl,static
             # Display the RR table
            print("record_no,name,type,result,ttl,static")
            for record in self.records:
                print(f"{record['record_no']},{record['name']},{record['type']},"
                      f"{record['result']},{record['ttl']},{record['static']}")


class DNSTypes:
    """
    A class to manage DNS query types and their corresponding codes.

    Examples:
    >>> DNSTypes.get_type_code('A')
    8
    >>> DNSTypes.get_type_name(0b0100)
    'AAAA'
    """

    name_to_code = {
        "A": 0b1000,
        "AAAA": 0b0100,
        "CNAME": 0b0010,
        "NS": 0b0001,
    }

    code_to_name = {code: name for name, code in name_to_code.items()}

    @staticmethod
    def get_type_code(type_name: str):
        """Gets the code for the given DNS query type name, or None"""
        return DNSTypes.name_to_code.get(type_name, None)

    @staticmethod
    def get_type_name(type_code: int):
        """Gets the DNS query type name for the given code, or None"""
        return DNSTypes.code_to_name.get(type_code, None)


class UDPConnection:
    """A class to handle UDP socket communication, capable of acting as both a client and a server."""

    def __init__(self, timeout: int = 1):
        """Initializes the UDPConnection instance with a timeout. Defaults to 1."""
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.settimeout(timeout)
        self.is_bound = False

    def send_message(self, message: str, address: tuple[str, int]):
        """Sends a message to the specified address."""
        self.socket.sendto(message, address)

    def receive_message(self):
        """
        Receives a message from the socket.

        Returns:
            tuple (data, address): The received message and the address it came from.

        Raises:
            KeyboardInterrupt: If the program is interrupted manually.
        """
        while True:
            try:
                data, address = self.socket.recvfrom(4096)
                return data, address
            except socket.timeout:
                continue
            except OSError as e:
                if e.errno == errno.ECONNRESET:
                    print("Error: Unable to reach the other socket. It might not be up and running.")
                else:
                    print(f"Socket error: {e}")
                self.close()
                sys.exit(1)
            except KeyboardInterrupt:
                raise

    def bind(self, address: tuple[str, int]):
        """Binds the socket to the given address. This means it will be a server."""
        if self.is_bound:
            print(f"Socket is already bound to address: {self.socket.getsockname()}")
            return
        self.socket.bind(address)
        self.is_bound = True

    def close(self):
        """Closes the UDP socket."""
        self.socket.close()


if __name__ == "__main__":
    main()