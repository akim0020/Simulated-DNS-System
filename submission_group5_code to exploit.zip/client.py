import errno
import socket
import sys
import threading
import time


# Global variables
transaction_id = 0  # Initialize global transaction ID

# This will temporarily hold queries until a response is received
# pending_queries = []

def handle_request(rr_table, hostname, query_code):

    global transaction_id

    # Check RR table for record
    # print(f"Hostname: {hostname}")
    # print("Check RR table")
    record = rr_table.get_record_by_name(hostname)
    # print(f"Record value after check RR table: {record}")
    if record is not None:
        # print(f"Found in RR Table: {record}")
        rr_table.display_table()
        return
    # else:
        # print(f"Record for {hostname} not found in local RR Table, querying local server...")

    # If not found, create a query and send it
    query = serialize(hostname, query_code)
    local_dns_address = ("127.0.0.1", 21000)

    # Generate a unique Transaction ID for this request
    # txn_id = transaction_id

    # Temporarily store the query until response is received
    # pending_queries[txn_id] = {'hostname': hostname, 'query_code': query_code}

    udp_client.send_message(query, local_dns_address)
    
    # Receive the response and process it
    response, _ = udp_client.receive_message()
    record = deserialize(response)

    # Parse query to extract the hostname (domain)
    # print(f"Query/Response: {record}")
    
    # If the response is valid, add it to the RR table
    if record:
        rr_table.add_record(record['hostname'], DNSTypes.get_type_name(record['type']), record['result'], static=0)

    # Display RR table
    rr_table.display_table()
    return
    # pass


def main():

    global rr_table
    rr_table = RRTable()  # Initialize RR Table

    global udp_client 
    udp_client = UDPConnection(timeout=1)  # Initialize UDP client
    
    try:
        while True:
            input_value = input("Enter the hostname (or type 'quit' to exit) ")
            if input_value.lower() == "quit":
                break

            hostname = input_value
            query_code = DNSTypes.get_type_code("A")

            # For extra credit, let users decide the query type (e.g. A, AAAA, NS, CNAME)
            # This means input_value will be two values separated by a space

            handle_request(rr_table,hostname,query_code)

    except KeyboardInterrupt:
        print("Keyboard interrupt received, exiting...")
    finally:
        # Close UDP socket
        udp_client.close()
        # pass


def serialize(hostname, query_code):
    # Consider creating a serialize function
    # This can help prepare data to send through the socket
    global transaction_id
    transaction_id += 1  # Increment transaction ID for every query
    flag = 0b0000 # Define flags (0b0000 is query flag, as per DNS)

     # Convert to byte
    trans_ID_query = transaction_id.to_bytes(4, byteorder='big')
    flag_query = flag.to_bytes(1, byteorder='big')
    type_query = query_code.to_bytes(1, byteorder='big')
    
    # Encode hostname
    labels = hostname.split('.') # Split the domain name into labels (splitting by '.')
    domain_bytes = [] # Create a list to hold the encoded domain name bytes

    # For each label in the domain
    for label in labels:
        # Add the length of the label as the first byte
        domain_bytes.append(len(label))
        
        # Add the ASCII values of the characters in the label
        domain_bytes.extend(ord(char) for char in label)

    # Append a null byte to signify the end of the domain name
    domain_bytes.append(0)
    # Convert domain name labels into bytes
    hostname_query = bytes(domain_bytes)

    # Combine all parts of the query into a single byte string
    query = trans_ID_query + flag_query + hostname_query + type_query

    return query
    
    # pass

def deserialize(response):
    # Consider creating a deserialize function
    # This can help prepare data that is received from the socket
     
    # Initialize a pointer to track where we are in the response
    pointer = 0

    # Step 1: Extract the Transaction ID (4 bytes)
    trans_ID = int.from_bytes(response[pointer:pointer + 4], byteorder='big')
    pointer += 4

    # Step 2: Extract the flag (1 byte)
    flag = response[pointer]
    pointer += 1

    # Step 3: Decode the hostname
    labels = []
    while response[pointer] != 0:
        label_len = response[pointer]
        pointer += 1
        label = response[pointer:pointer + label_len].decode('ascii')
        labels.append(label)
        pointer += label_len
    pointer += 1  # Skip the null byte that ends the hostname

    hostname = '.'.join(labels)

    # Step 4: Extract the query type (1 bytes)
    query_type = response[pointer]
    pointer += 1

    # Step 5: Handle Response
    if flag == 0x01:  # This is a response
        # Extract TTL (4 bytes)
        # ttl = int.from_bytes(response[pointer:pointer + 4], byteorder='big')
        # pointer += 4

        # Extract Result (IPv4 address for A record - 4 bytes)
        result_ip = socket.inet_ntoa(response[pointer:pointer + 4])
        pointer += 4

        # Return the deserialized DNS response
        return {
            'transaction_id': trans_ID,
            'flag': flag,
            'hostname': hostname,
            'type': query_type,
            # 'ttl': ttl,
            'result': result_ip
        }
    else:
        # Return the deserialized DNS query (without TTL and result)
        return {
            'transaction_id': trans_ID,
            'flag': flag,
            'hostname': hostname,
            'type': query_type
        }
    # pass

class RRTable:
    def __init__(self):
        # self.records = ?
        self.records = []  # A list to hold all the records
        self.record_number = 0

        # Start the background thread
        self.lock = threading.Lock()
        self.thread = threading.Thread(target=self.__decrement_ttl, daemon=True)
        self.thread.start()

    def add_record(self, name, type, result, static):
        with self.lock:
            
            self.record_number += 1  # Increment record number for the next record
            # Add a new record to the RR table
            record = {
                "record_no": self.record_number,
                "name": name,
                "type": type,
                "result": result,
                "ttl": 60 if static == 0 else None,  # TTL is 60 if dynamic, None if static
                "static": static #static= 0
            }
            self.records.append(record)
            #pass

    def get_record_by_name(self, name):
        with self.lock:
            # Find and return the record by its name
            for record in self.records:
                if record['name'] == name:
                    return record
            return None  # Return None if no matching record is found
    
    def get_record(self, record_number):
        with self.lock:
            # Find and return the record with the specified record number
            for record in self.records:
                if record['record_no'] == record_number:
                    return record
            return None  # Return None if no matching record is found
            #pass

    def display_table(self):
        with self.lock:
            # Display the table in the following format (include the column names):
            # record_number,name,type,result,ttl,static
             # Display the RR table
            print("record_no,name,type,result,ttl,static")
            for record in self.records:
                print(f"{record['record_no']},{record['name']},{record['type']},"
                      f"{record['result']},{record['ttl']},{record['static']}")
            
            #pass

    def __decrement_ttl(self):
        while True:
            with self.lock:
                # Decrement ttl
                for record in self.records:
                    if record['static'] == 0 and record['ttl'] is not None:
                        if record['ttl'] > 0:
                            record['ttl'] -= 1  # Decrement TTL by 1
                # Remove expired records after decrementing TTL
                self.__remove_expired_records()
            time.sleep(1)

    def __remove_expired_records(self):
        # This method is only called within a locked context
        self.records = [record for record in self.records if not (record['static'] == 0 and record['ttl'] == 0)]
        # Remove expired records
        # Update record numbers
        for i, record in enumerate(self.records):
            self.record_number = i+1
            record['record_no'] = self.record_number  # Reassign record number to maintain sequence
        
        #pass


class DNSTypes:
    """
    A class to manage DNS query types and their corresponding codes.

    Examples:
    >>> DNSTypes.get_type_code('A')
    8
    >>> DNSTypes.get_type_name(0b0100)
    'AAAA'
    """

    name_to_code = {
        "A": 0b1000,
        "AAAA": 0b0100,
        "CNAME": 0b0010,
        "NS": 0b0001,
    }

    code_to_name = {code: name for name, code in name_to_code.items()}

    @staticmethod
    def get_type_code(type_name: str):
        """Gets the code for the given DNS query type name, or None"""
        return DNSTypes.name_to_code.get(type_name, None)

    @staticmethod
    def get_type_name(type_code: int):
        """Gets the DNS query type name for the given code, or None"""
        return DNSTypes.code_to_name.get(type_code, None)


class UDPConnection:
    """A class to handle UDP socket communication, capable of acting as both a client and a server."""

    def __init__(self, timeout: int = 1):
        """Initializes the UDPConnection instance with a timeout. Defaults to 1."""
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.settimeout(timeout)
        self.is_bound = False

    def send_message(self, message: str, address: tuple[str, int]):
        """Sends a message to the specified address."""
        # self.socket.sendto(message.encode(), address)
        self.socket.sendto(message, address)

    def receive_message(self):
        """
        Receives a message from the socket.

        Returns:
            tuple (data, address): The received message and the address it came from.

        Raises:
            KeyboardInterrupt: If the program is interrupted manually.
        """
        while True:
            try:
                data, address = self.socket.recvfrom(4096)
                # return data.decode(), address
                return data, address
            except socket.timeout:
                continue
            except OSError as e:
                if e.errno == errno.ECONNRESET:
                    print("Error: Unable to reach the other socket. It might not be up and running.")
                else:
                    print(f"Socket error: {e}")
                self.close()
                sys.exit(1)
            except KeyboardInterrupt:
                raise

    def bind(self, address: tuple[str, int]):
        """Binds the socket to the given address. This means it will be a server."""
        if self.is_bound:
            print(f"Socket is already bound to address: {self.socket.getsockname()}")
            return
        self.socket.bind(address)
        self.is_bound = True

    def close(self):
        """Closes the UDP socket."""
        self.socket.close()


if __name__ == "__main__":
    main()