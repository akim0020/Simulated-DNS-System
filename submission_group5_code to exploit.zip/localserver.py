import errno
import socket
import sys
import threading
import time



def listen():
    try:
        while True:
            # Wait for query
            binary_query, client_address = udp_server_local.receive_message()
            record = deserialize(binary_query)

            # Parse query to extract the hostname (domain)
            hostname = record['hostname']
            
            # Check RR table for record
            check_record = rr_table_local.get_record_by_name(hostname)

            if check_record:
                rr_table_local.display_table()
                response = serialize(record['transaction_id'], hostname, record['type'], check_record['result'], is_response=True)
                udp_server_local.send_message(response, client_address)
            else:
               
            # This means parsing the query to get the domain (e.g. amazone.com from shop.amazone.com)
            # With the domain, you can do a self lookup to get the NS record of the domain (e.g. dns.amazone.com)
            # With the server name, you can do a self lookup to get the IP address (e.g. 127.0.0.1)

            # When sending a query to the authoritative DNS server, use port 22000

                # Query the authoritative DNS server for the NS record
                authoritative_dns_address = ("127.0.0.1", 22000)  # Example authoritative DNS server address
                query = serialize(record['transaction_id'], hostname, record['type'],'', is_response=False)
                udp_server_local.send_message(query, authoritative_dns_address)

                # Wait for the authoritative DNS server response
                response, _ = udp_server_local.receive_message()
                record = deserialize(response)

            # Then save the record if valid
            # Else, add "Record not found" in the DNS response

            # The format of the DNS query and response is in the project description

            # Display RR table
            # pass
                # print(f"Query/Response: {record}")
                if record and record['result'] != "Record not found":
                                          
                        # Add the new record to the local RR Table
                        rr_table_local.add_record(record['hostname'], DNSTypes.get_type_name(record['type']), record['result'], static=0)
                        # print(f"Received new record from authoritative server: {record}")
                else:
                        # Respond with "Record not found"
                        # print(f"Record for {hostname} not found, sending 'Record not found' response")
                        response = serialize(record['transaction_id'], hostname, record['type'], "Record not found", is_response=True)
                
                udp_server_local.send_message(response, client_address)
                # Display RR table after each query
                # print("RR Table:")
                rr_table_local.display_table()


    except KeyboardInterrupt:
        print("Keyboard interrupt received, exiting...")
    finally:
        # Close UDP socket
        udp_server_local.close()
        


def main():
    # Add initial records
    # These can be found in the test cases diagram
    global rr_table_local
    rr_table_local = RRTable()  # Initialize RR Table

    global udp_server_local 
    udp_server_local = UDPConnection(timeout=1)  # Initialize UDP client

    # rr_table.add_record(record['name'], record['type'], record['result'], static=0)
    rr_table_local.add_record("www.csusm.edu","A","144.37.5.45",static=1)
    rr_table_local.add_record("my.csusm.edu","A","144.37.5.150",static=1)
    rr_table_local.add_record("amazone.com","NS","dns.amazone.com",static=1)
    rr_table_local.add_record("dns.amazone.com","A","127.0.0.1",static=1)        

    
    local_dns_address = ("127.0.0.1", 21000)
    udp_server_local.bind(local_dns_address)
    # Bind address to UDP socket

    listen()


def serialize(transaction_id, hostname, query_code, result, is_response=False):
    # Consider creating a serialize function
    # This can help prepare data to send through the socket
    
    # Convert transaction ID to 4 bytes
    trans_ID_query = transaction_id.to_bytes(4, byteorder='big')
    
    # Convert query type to 1 bytes (DNS query types are 16 bits)
    type_query = query_code.to_bytes(1, byteorder='big')
    
    # Encode hostname
    labels = hostname.split('.') # Split the domain name into labels (splitting by '.')
    domain_bytes = [] # Create a list to hold the encoded domain name bytes

    # For each label in the domain
    for label in labels:
        # Add the length of the label as the first byte
        domain_bytes.append(len(label))
        
        # Add the ASCII values of the characters in the label
        domain_bytes.extend(ord(char) for char in label)

    # Append a null byte to signify the end of the domain name
    domain_bytes.append(0)
    # Convert domain name labels into bytes
    hostname_query = bytes(domain_bytes)

    # Set the flag for query or response
    if not is_response:
        flag = 0b0000 
        flag_query = flag.to_bytes(1, byteorder='big')
        # Combine all parts of the query into a single byte string
        query = trans_ID_query + flag_query + hostname_query + type_query
    else:
        flag = 0x0001   
        flag_query = flag.to_bytes(1, byteorder='big')
        # ttl_query = ttl.to_bytes(4, byteorder='big') #4 bytes
        result_query = socket.inet_aton(result) #4 bytes

        # Combine all parts of the query into a single byte string
        query = trans_ID_query + flag_query + hostname_query + type_query + result_query

    return query
    
    #pass


def deserialize(response):
    # Consider creating a deserialize function
    # This can help prepare data that is received from the socket
    # Read transaction ID and check it matches

    # Initialize a pointer to track where we are in the response
    pointer = 0

    # Step 1: Extract the Transaction ID (4 bytes)
    trans_ID = int.from_bytes(response[pointer:pointer + 4], byteorder='big')
    pointer += 4

    # Step 2: Extract the flag (1 byte)
    flag = response[pointer]
    pointer += 1

    # Step 3: Decode the hostname
    labels = []
    while response[pointer] != 0:
        label_len = response[pointer]
        pointer += 1
        label = response[pointer:pointer + label_len].decode('ascii')
        labels.append(label)
        pointer += label_len
    pointer += 1  # Skip the null byte that ends the hostname

    hostname = '.'.join(labels)

    # Step 4: Extract the query type (1 bytes)
    query_type = response[pointer]
    pointer += 1

    # Step 5: Handle Response
    if flag == 0x01:  # This is a response
        # Extract TTL (4 bytes)
        # ttl = int.from_bytes(response[pointer:pointer + 4], byteorder='big')
        # pointer += 4

        # Extract Result (IPv4 address for A record - 4 bytes)
        result_ip = socket.inet_ntoa(response[pointer:pointer + 4])
        pointer += 4

        # Return the deserialized DNS response
        return {
            'transaction_id': trans_ID,
            'flag': flag,
            'hostname': hostname,
            'type': query_type,
            'result': result_ip
        }
    else:
        # Return the deserialized DNS query (without TTL and result)
        return {
            'transaction_id': trans_ID,
            'flag': flag,
            'hostname': hostname,
            'type': query_type
        }


class RRTable:
    def __init__(self):
        # self.records = ?
        self.records = []  # A list to hold all the records
        self.record_number = 0

        # Start the background thread
        self.lock = threading.Lock()
        self.thread = threading.Thread(target=self.__decrement_ttl, daemon=True)
        self.thread.start()

    def add_record(self, name, type, result, static):
        with self.lock:

            self.record_number += 1  # Increment record number for the next record
            # Add a new record to the RR table
            record = {
                "record_no": self.record_number,
                "name": name,
                "type": type,
                "result": result,
                "ttl": 60 if static == 0 else None,  # TTL is 60 if dynamic, None if static
                "static": static #static= 0
            }
            self.records.append(record)            
            #pass

    def get_record_by_name(self, name):
        with self.lock:
            # Find and return the record by its name
            for record in self.records:
                if record['name'] == name:
                    return record
            return None  # Return None if no matching record is found
    
    def get_record(self, record_number):
        with self.lock:
            # Find and return the record with the specified record number
            for record in self.records:
                if record['record_no'] == record_number:
                    return record
            return None  # Return None if no matching record is found
            #pass

    def display_table(self):
        with self.lock:
            # Display the table in the following format (include the column names):
            # record_number,name,type,result,ttl,static
             # Display the RR table
            print("record_no,name,type,result,ttl,static")
            for record in self.records:
                print(f"{record['record_no']},{record['name']},{record['type']},"
                      f"{record['result']},{record['ttl']},{record['static']}")
            
            #pass

    def __decrement_ttl(self):
        while True:
            with self.lock:
                # Decrement ttl
                for record in self.records:
                    if record['static'] == 0 and record['ttl'] is not None:
                        if record['ttl'] > 0:
                            record['ttl'] -= 1  # Decrement TTL by 1
                # Remove expired records after decrementing TTL
                self.__remove_expired_records()
            time.sleep(1)

    def __remove_expired_records(self):
        # This method is only called within a locked context
        self.records = [record for record in self.records if not (record['static'] == 0 and record['ttl'] == 0)]
        # Remove expired records
        # Update record numbers
        for i, record in enumerate(self.records):
            self.record_number = i+1
            record['record_no'] = self.record_number  # Reassign record number to maintain sequence
        #pass

class DNSTypes:
    """
    A class to manage DNS query types and their corresponding codes.

    Examples:
    >>> DNSTypes.get_type_code('A')
    8
    >>> DNSTypes.get_type_name(0b0100)
    'AAAA'
    """

    name_to_code = {
        "A": 0b1000,
        "AAAA": 0b0100,
        "CNAME": 0b0010,
        "NS": 0b0001,
    }

    code_to_name = {code: name for name, code in name_to_code.items()}

    @staticmethod
    def get_type_code(type_name: str):
        """Gets the code for the given DNS query type name, or None"""
        return DNSTypes.name_to_code.get(type_name, None)

    @staticmethod
    def get_type_name(type_code: int):
        """Gets the DNS query type name for the given code, or None"""
        return DNSTypes.code_to_name.get(type_code, None)


class UDPConnection:
    """A class to handle UDP socket communication, capable of acting as both a client and a server."""

    def __init__(self, timeout: int = 1):
        """Initializes the UDPConnection instance with a timeout. Defaults to 1."""
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.settimeout(timeout)
        self.is_bound = False

    def send_message(self, message: str, address: tuple[str, int]):
        """Sends a message to the specified address."""
        # self.socket.sendto(message.encode(), address)
        self.socket.sendto(message, address)


    def receive_message(self):
        """
        Receives a message from the socket.

        Returns:
            tuple (data, address): The received message and the address it came from.

        Raises:
            KeyboardInterrupt: If the program is interrupted manually.
        """
        while True:
            try:
                data, address = self.socket.recvfrom(4096)
                # return data.decode(), address
                return data, address
            except socket.timeout:
                continue
            except OSError as e:
                if e.errno == errno.ECONNRESET:
                    print("Error: Unable to reach the other socket. It might not be up and running.")
                else:
                    print(f"Socket error: {e}")
                self.close()
                sys.exit(1)
            except KeyboardInterrupt:
                raise

    def bind(self, address: tuple[str, int]):
        """Binds the socket to the given address. This means it will be a server."""
        if self.is_bound:
            print(f"Socket is already bound to address: {self.socket.getsockname()}")
            return
        self.socket.bind(address)
        self.is_bound = True

    def close(self):
        """Closes the UDP socket."""
        self.socket.close()


if __name__ == "__main__":
    main()