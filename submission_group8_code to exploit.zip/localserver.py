import errno
import socket
import sys
import threading
import time

"""
def listen(local_dns, rr_table, authoritative_dns_address):
"""

def listen():
    try:
        while True:
            print("\nWaiting for DNS query...")
            # Receive a DNS query from the client
            message = udp.receive_message()
            """
            data, client_address = local_dns.receive_message()
            print(f"Received query: {data} from {client_address}")
            """
            # Check RR table for record
            query = deserialize_client(message[0])
            record = table.get_record(query['name'])
            if record['result'] == "Record not found":
                # If not found, ask the authoritative DNS server of the requested hostname/domain
                domain = query['name'][query['name'].find('.')+1:]

                # With the domain, you can do a self lookup to get the NS record of the domain
                dns = table.get_record(domain)

                if(dns['result'] != "Record not found" and dns['type'] == "NS"):
                    dns_add = table.get_record(dns['result'])
                    auth_dns_address = (dns_add['result'],22000)
                    udp.send_message(message[0],auth_dns_address)
                    new_response = deserialize_server(udp.receive_message()[0])
                    # Then save the record if valid
                    if( new_response['transID'] == query['transID'] and new_response['flag'] == '0001' and new_response['name'] == query['name'] and new_response['type'] == query['type'],2):
                        table.add_record(new_response['name'],new_response['type'],new_response['result'],60,0)
                        record = table.get_record(query['name'])
                # Else, add "Record not found" in the DNS response
                else: 
                    pass
            # Receive response from the authoritative DNS server
            response = {
                'transID': query['transID'],
                'flag': '0001',
                'name': record['name'],
                'type': bin(DNSTypes.get_type_code(query['type']))[2:].zfill(4),
                'ttl': record['ttl'],
                'result': record['result']
            }
            udp.send_message(serialize(response),message[1])
            
            # Print the RR Table
            table.display_table()
            pass
    except KeyboardInterrupt:
        print("Keyboard interrupt received, exiting...")
    finally:
        # Close UDP socket
        udp.close()
        pass


def main():
    # Add initial records
    # These can be found in the test cases diagram
    global table
    table = RRTable()
    table.add_record("www.csusm.edu","A","144.37.5.45",None,1)
    table.add_record("my.csusm.edu","A","144.37.5.150",None,1)
    table.add_record("amazone.com","NS","dns.amazone.com",None,1)
    table.add_record("dns.amazone.com","A","127.0.0.1",None,1)

    # Local DNS server setup
    local_dns_address = ("127.0.0.1", 21000)
    # Bind address to UDP socket
    global udp
    udp = UDPConnection()
    udp.bind(local_dns_address)

    listen()

# Prepare data to send through the socket.
def serialize(response):
    ttl = response['ttl']
    if(ttl == None):
        ttl = '00'
    else:
        ttl = str(ttl).zfill(2)
    return response['transID'] + response['flag'] + response['name'] + response['type'] + ttl + response['result']

# Prepare received data for processing.
def deserialize_client(data):
    nameindex = data.find('1',36)
    nameindex2 = data.find('0',36)
    recieve = {
        'transID': data[:32],
        'flag': data[32:35],
        'name': data[36:nameindex],
        'type': DNSTypes.get_type_name(int(data[nameindex:],2)),# query_name, query_type
    }
    return recieve

def deserialize_server(data):
    #Deserialises response from authoritative dns server
    nameindex = data.find('1',36)
    nameindex2 = data.find('0',36)

    # The structure of DNS query and response
    if(nameindex > nameindex2): nameindex = nameindex2
    recieve = {
        'transID': data[:32],
        'flag': data[32:36],
        'name': data[36:nameindex],
        'type': DNSTypes.get_type_name(int(data[nameindex:nameindex+4],2)),
        'TTL': data[nameindex+4:nameindex+6],
        'result': data[nameindex+6:]
    }

    return recieve

class RRTable:
    def __init__(self):
        # List of dictionaries: {'name': str, 'type': str, 'result': str, 'ttl': int, 'static': bool}
        self.records = {

        }
        self.record_number = 0

        self.lock = threading.Lock()
        self.thread = threading.Thread(target=self.__decrement_ttl, daemon=True)
        self.thread.start()

    def add_record(self,name,record_type,result,TTL,static):
        with self.lock:
            record = {
                'name': name,
                'type': record_type,
                'result': result,
                'ttl': TTL,
                'static': static
            }
            self.records[name] = record
            self.record_number += 1

    def get_record(self,name):
        with self.lock:
            if name in self.records:
                return self.records[name]
            else:
                return {'name': name, 'result':"Record not found", 'ttl': None}

    def display_table(self):
        with self.lock:
            # Display the table in the following format
            # Print record_no,name,type,result,ttl,static
            print("record_no,name,type,result,ttl,static")
            num = 0
            for record in self.records.values():
                print("{},{},{},{},{},{}".format(num,record['name'],record['type'],record['result'],record['ttl'],record['static']))
                num += 1

    def __decrement_ttl(self):
        while True:
            with self.lock:
                # Decrement ttl
                to_delete = []
                for record in self.records.values():
                    if(record['ttl'] != None):
                        record['ttl'] -= 1
                        if record['ttl'] <= 0:
                            to_delete.append(record['name'])
                            
                    pass
                self.__remove_expired_records(to_delete)
            time.sleep(1)

    def __remove_expired_records(self,to_delete):
        """if (record["ttl"] is not None and record["ttl"] > 0) or record["static"]"""

        for record in to_delete:
            del self.records[record]
            self.record_number -= 1
        # Remove expired records
        # Update record numbers
        pass

class DNSTypes:

    name_to_code = {
        "A": 0b1000,
        "AAAA": 0b0100,
        "CNAME": 0b0010,
        "NS": 0b0001,
    }

    code_to_name = {code: name for name, code in name_to_code.items()}

    # Gets the code for the given DNS query type name, or None
    @staticmethod
    def get_type_code(type_name: str):
        return DNSTypes.name_to_code.get(type_name, None)

    # Gets the code for the given DNS query type name, or None
    @staticmethod
    def get_type_name(type_code: int):
        return DNSTypes.code_to_name.get(type_code, None)


class UDPConnection:
    """A class to handle UDP socket communication, capable of acting as both a client and a server."""

    def __init__(self, timeout: int = 1):
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.settimeout(timeout)
        self.is_bound = False

    def send_message(self, message: str, address: tuple[str, int]):
        self.socket.sendto(message.encode(), address)

    def receive_message(self):
        """data, address = self.socket.recvfrom(4096)
                return data.decode(), address
        """
        while True:
            try:
                data, address = self.socket.recvfrom(4096)
                return data.decode(), address
            except socket.timeout:
                continue
            except OSError as e:
                if e.errno == errno.ECONNRESET:
                    print("Error: Unable to reach the other socket. It might not be up and running.")
                else:
                    print(f"Socket error: {e}")
                self.close()
                sys.exit(1)
            except KeyboardInterrupt:
                raise

    def bind(self, address: tuple[str, int]):
        if self.is_bound:
            print(f"Socket is already bound to address: {self.socket.getsockname()}")
            return
        self.socket.bind(address)
        self.is_bound = True

    def close(self):
        # Closes the UDP socket
        self.socket.close()

if __name__ == "__main__":
    main()