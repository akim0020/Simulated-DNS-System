import errno
import socket
import sys
import threading
import time

transID = 0

def handle_request(name: str, query_code: str):
    # Check RR table for record
    # If found, display the record
    # If not found, ask the local DNS server, then save the record if valid
    # local_dns_address = ("127.0.0.1", 21000)
    # The format of the DNS query and response is in the project description

    record = ClientRecords.get_record(name)
    if record['result'] == "not found":
        local_dns_address = ("127.0.0.1", 21000)
        transID
        request = {
            'transID': bin(transID)[2:].zfill(32),
            'flag': '0000',
            'name': name,
            'type': bin(query_code)[2:].zfill(4),
        }
        query = serialize(request)
        transID += 1
        udp.send_message(query, local_dns_address)
        message = udp.receive_message(0)
        response = deserialize(message)

        if(response['transID'] == request['transID'] and response['flag'] == '1000' and response['name'] == request['name'] and response['type'] == DNSTypes.get_type_name(int(request['type'],2))):                                                       
            ClientRecords.add_record(response['name'], response['type'], response['result'], response['ttl'], False)
            del(request)

    ClientRecords.display_table()

def main():
    global ClientRecords , udp
    ClientRecords = RRTable()
    UDP = UDPConnection()

    try:
        while True:
            input_value = input("Enter the hostname (or type 'quit' to exit) ")
            if input_value.lower() == "quit":
                break

            hostname = input_value
            query_code = DNSTypes.get_type_code("A")

            # For extra credit, let users decide the query type (e.g. A, AAAA, NS, CNAME)
            # This means input_value will be two values separated by a space

            handle_request(hostname, query_code)

    except KeyboardInterrupt:
        print("Keyboard interrupt received, exiting...")
    finally:
        # Close UDP socket
        UDP.close()
        pass


def serialize(request):
    # Consider creating a serialize function
    # This can help prepare data to send through the socket
    return request['transID'] + request['flag'] + request['name'] + request['type']


def deserialize(data):
    # Consider creating a deserialize function
    # This can help prepare data that is received from the socket
    Nameindex = data.find()
    nameIndex =data.find()
    if(Nameindex > nameIndex): Nameindex = nameIndex
    receive = {
        'transID': data[0:32],
        'flag': data[32:36],
        'name': data[36:Nameindex],
        'type': data[Nameindex:Nameindex+4],
        'result': data[Nameindex+4:],
        'ttl': data[Nameindex+4:Nameindex+8]
    }
    return receive

class RRTable:
    def __init__(self):
        self.records = []
        # self.records = ?
        self.record_number = 0

        # Start the background thread
        self.lock = threading.Lock()
        self.thread = threading.Thread(target=self.__decrement_ttl, daemon=True)
        self.thread.start()

    def add_record(self, name: str, type: str, result: str, ttl: int, static: bool):
        with self.lock:
            record = { 'name': name, 'type': type, 'result': result, 'ttl': ttl, 'static': static }
            self.records[name] = record
            self.record_number += 1
        

    def get_record(self,name: str):
        with self.lock:
            if name in self.records:
                return self.records[name]
            else:
                return {'result': 'not found'}
            

    def display_table(self):
        with self.lock:
            # Display the table in the following format (include the column names):
            # record_number,name,type,result,ttl,static
            print("record_number,name,type,result,ttl,static")
            i = 0
            for record in self.records:
                print(f"{i},{record['name']},{record['type']},{record['result']},{record['ttl']},{record['static']}")
                i += 1

    def __decrement_ttl(self):
        while True:
            with self.lock:
                # Decrement ttl
                delete_record = []
                for record in self.records:
                    if(record['ttl'] != None):
                        record['ttl'] -= 1
                    if record['ttl'] <= 0:
                        delete_record.append(record['name'])
            self.__remove_expired_records(delete_record)
        time.sleep(1)

    def __remove_expired_records(self, delete_record):
        # This method is only called within a locked context
        # Remove expired records
        # I think I want do do something similar to this, but I'm not sure how to implement it becuase I keep getting the attribute error mentioned above
        # return [record for record in self.records if record.ttl < 0]
        # Update record numbers
        for record in delete_record:
            del self.records[record]
            self.record_number -= 1
        pass


class DNSTypes:
    """
    A class to manage DNS query types and their corresponding codes.

    Examples:
    >>> DNSTypes.get_type_code('A')
    8
    >>> DNSTypes.get_type_name(0b0100)
    'AAAA'
    """

    name_to_code = {
        "A": 0b1000,
        "AAAA": 0b0100,
        "CNAME": 0b0010,
        "NS": 0b0001,
    }

    code_to_name = {code: name for name, code in name_to_code.items()}

    @staticmethod
    def get_type_code(type_name: str):
        """Gets the code for the given DNS query type name, or None"""
        return DNSTypes.name_to_code.get(type_name, None)

    @staticmethod
    def get_type_name(type_code: int):
        """Gets the DNS query type name for the given code, or None"""
        return DNSTypes.code_to_name.get(type_code, None)


class UDPConnection:
    """A class to handle UDP socket communication, capable of acting as both a client and a server."""

    def __init__(self, timeout: int = 1):
        """Initializes the UDPConnection instance with a timeout. Defaults to 1."""
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.settimeout(timeout)
        self.is_bound = False

    def send_message(self, message: str, address: tuple[str, int]):
        """Sends a message to the specified address."""
        self.socket.sendto(message.encode(), address)

    def receive_message(self):
        """
        Receives a message from the socket.

        Returns:
            tuple (data, address): The received message and the address it came from.

        Raises:
            KeyboardInterrupt: If the program is interrupted manually.
        """
        while True:
            try:
                data, address = self.socket.recvfrom(4096)
                return data.decode(), address
            except socket.timeout:
                continue
            except OSError as e:
                if e.errno == errno.ECONNRESET:
                    print("Error: Unable to reach the other socket. It might not be up and running.")
                else:
                    print(f"Socket error: {e}")
                self.close()
                sys.exit(1)
            except KeyboardInterrupt:
                raise

    def bind(self, address: tuple[str, int]):
        """Binds the socket to the given address. This means it will be a server."""
        if self.is_bound:
            print(f"Socket is already bound to address: {self.socket.getsockname()}")
            return
        self.socket.bind(address)
        self.is_bound = True

    def close(self):
        """Closes the UDP socket."""
        self.socket.close()


if __name__ == "__main__":
    main()
